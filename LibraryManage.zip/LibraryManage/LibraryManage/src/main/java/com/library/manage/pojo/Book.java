package com.library.manage.pojo;

import java.util.Date;

/**
 * 图书类
 */
public class Book {
    private int id;
    private String name;
    private String author;
    private Date publishDate;
    private String isbn;
    private String category;
    private String classification;

    public Book() {
    }

    public Book(int id, String name, String author, Date publishDate, String isbn, String category, String classification) {
        this.id = id;
        this.name = name;
        this.author = author;
        this.publishDate = publishDate;
        this.isbn = isbn;
        this.category = category;
        this.classification = classification;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public Date getPublishDate() {
        return publishDate;
    }

    public void setPublishDate(Date publishDate) {
        this.publishDate = publishDate;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getClassification() {
        return classification;
    }

    public void setClassification(String classification) {
        this.classification = classification;
    }

    @Override
    public String toString() {
        return String.format("书名: %s, 作者: %s, ISBN: %s, 出版日期：%s, 类别: %s, 分类: %s",
                name, author, isbn, publishDate, category, classification);
    }


}