package com.library.manage.pojo;

import java.util.Date;

/**
 * 计算机书籍
 */
public class ComputerBook extends Book {
    private final static String CATEGORY = "计算机"; // 静态成员变量，用于表示书籍的类别，方便后续的查询和过滤，类型为 String

    private String programmingLanguage; // 适用编程语言

    public ComputerBook() {
    }

    public ComputerBook(int id, String name, String author, Date publishDate, String isbn, String category, String programmingLanguage) {
        super(id, name, author, publishDate, isbn, category, programmingLanguage);
        this.programmingLanguage = programmingLanguage;
    }

    public void setProgrammingLanguage(String programmingLanguage) {
        this.programmingLanguage = programmingLanguage;
    }

    public String getProgrammingLanguage() {
        return programmingLanguage;
    }

    @Override
    public String toString() {
        return String.format("书名: %s, 作者: %s, 出版日期: %s, ISBN: %s, 类别: %s, 第二类别: %s",
                super.getName(), super.getAuthor(), super.getPublishDate(), super.getIsbn(), CATEGORY, programmingLanguage);
    }
}