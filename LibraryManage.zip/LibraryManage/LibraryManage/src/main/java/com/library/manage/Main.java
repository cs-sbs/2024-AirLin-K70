package com.library.manage;

import com.library.manage.service.BookManager;
import com.library.manage.service.UserManager;
import com.library.manage.util.BackupTask;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        UserManager userManager = new UserManager();
        BookManager bookManager = new BookManager();

        // 启动备份线程
        Thread backupThread = new Thread(new BackupTask(bookManager));
        backupThread.setDaemon(true);
        backupThread.start();

        while (true) {
            System.out.println("\nWelcome to the Book Management System");
            System.out.println("1. Register");
            System.out.println("2. Login");
            System.out.println("3. View Books");
            System.out.println("4. Search Books");
            System.out.println("5. Add a Book (Admin Only)");
            System.out.println("6. Delete a Book (Admin Only)");
            System.out.println("7. Logout");
            System.out.println("8. Exit");
            System.out.print("Please enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // 清除换行符

            switch (choice) {
                case 1:
                    userManager.register(scanner);
                    break;
                case 2:
                    if (userManager.isLoggedIn()) {
                        System.out.println("**************** 当前用户已登录，无需再次登录！****************");
                        break;
                    } else {
                        userManager.login(scanner);
                    }
                    break;
                case 3:
                    if (!userManager.isLoggedIn()) {
                        System.out.println("**************** 亲先登录！****************");
                        break;
                    }
                    bookManager.viewBooks(scanner);
                    break;
                case 4:
                    if (!userManager.isLoggedIn()) {
                        System.out.println("**************** 亲先登录！****************");
                        break;
                    }
                    bookManager.searchBooks(scanner);
                    break;
                case 5:
                    if (!userManager.isLoggedIn()) {
                        System.out.println("**************** 亲先登录！****************");
                        break;
                    }
                    if (userManager.isAdminLoggedIn()) {
                        bookManager.addBook(scanner);
                    } else {
                        System.out.println("**************** 只有管理员可以添加图书！****************");
                    }
                    break;
                case 6:
                    if (!userManager.isLoggedIn()) {
                        System.out.println("亲先登录！");
                        break;
                    }
                    if (userManager.isAdminLoggedIn()) {
                        bookManager.deleteBook(scanner);
                    } else {
                        System.out.println("**************** 只有管理员可以删除图书！****************");
                    }
                    break;
                case 7:
                    if (userManager.isLoggedIn()) {
                        userManager.logout();
                    } else {
                        System.out.println("**************** 当前还没有登录！****************");
                    }
                    break;
                case 8:
                    System.out.println("**************** Exiting... Goodbye! ****************");
                    return;
                default:
                    System.out.println("**************** Invalid choice. Please try again.****************");
            }
        }
    }
}