package com.library.manage.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * 数据库工具类
 */
public class DBUtil {
    /**
     * 数据库连接ip
     */
    private static final String IP = "127.0.0.1";

    /**
     * 数据库端口
     */
    private static final Integer PORT = 3306;

    /**
     * 数据库名称
     */
    private static final String DATABASE = "library";

    /**
     * 数据库编码
     */
    private static final String ENCODING = "UTF-8";

    /**
     * 数据库用户名
     */
    private static final String LOGIN_NAME = "root";

    /**
     * 数据库密码
     */
    private static final String PASSWORD = "Fnst_1234";

    /**
     * 加载驱动
     */
    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    /**
     * 获取数据库连接
     *
     * @return Connection
     */
    public static Connection getConnection() throws SQLException {
        String url = String.format("jdbc:mysql://%s:%d/%s?characterEncoding=%s", IP, PORT, DATABASE, ENCODING);
        return DriverManager.getConnection(url, LOGIN_NAME, PASSWORD);
    }

    /**
     * 关闭数据库
     *
     * @param connection Connection
     */
    public static void closeConnection(Connection connection) {
        try {
            if (connection != null) {
                connection.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}