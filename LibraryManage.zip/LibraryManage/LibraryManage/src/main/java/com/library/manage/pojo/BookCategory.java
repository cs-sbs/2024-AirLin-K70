package com.library.manage.pojo;

public enum BookCategory {
        COMPUTER,
        MEDICINE,
        LITERATURE,
        LAW,
        OTHER
}