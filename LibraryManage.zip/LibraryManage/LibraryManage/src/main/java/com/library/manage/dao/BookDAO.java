package com.library.manage.dao;


import com.library.manage.pojo.Book;
import com.library.manage.pojo.BookCategory;
import com.library.manage.pojo.ComputerBook;
import com.library.manage.pojo.LawBook;
import com.library.manage.pojo.LiteratureBook;
import com.library.manage.pojo.MedicalBook;
import com.library.manage.util.DBUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

public class BookDAO implements BaseDAO<Book> {

    /**
     * 获取用户总数
     */
    public int getTotal() {
        return getTotal("Book");
    }

    /**
     * 添加书籍
     *
     * @param bean Book
     * @return int
     */
    @Override
    public int add(Book bean) {
        String sql = "INSERT INTO Book (name, author, publish_date, isbn, category, classification) VALUES (?, ?, ?, ?, ?, ?)";
        Connection connection = null;

        try {
            connection = DBUtil.getConnection();
            PreparedStatement ps = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, bean.getName());
            ps.setString(2, bean.getAuthor());
            ps.setTimestamp(3, new Timestamp(System.currentTimeMillis()));
            ps.setString(4, bean.getIsbn());
            ps.setString(5, bean.getCategory());
            ps.setString(6, bean.getClassification());

            int res = ps.executeUpdate();

            ResultSet generatedKeys = ps.getGeneratedKeys();
            if (generatedKeys.next()) {
                int id = generatedKeys.getInt(1);
                bean.setId(id);
            }
            return res;
        } catch (SQLException e) {
            handleException(e);
        } finally {
            DBUtil.closeConnection(connection);
        }
        return 0;
    }

    @Override
    public int delete(int id) {
        return 0;
    }

    /**
     * 删除书籍
     *
     * @param isbn String
     */
    public int delete(String isbn) {
        String sql = "DELETE FROM Book WHERE isbn = ?";
        Connection connection = null;
        try {
            connection = DBUtil.getConnection();
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, isbn);
            return ps.executeUpdate();
        } catch (SQLException e) {
            handleException(e);
        } finally {
            DBUtil.closeConnection(connection);
        }
        return 0;
    }

    /**
     * 获取所有书籍
     *
     * @return List<Book>
     */
    public List<Book> list() {
        List<Book> books = new ArrayList<>();
        String sql = "SELECT * FROM Book";
        Connection connection = null;
        try {
            connection = DBUtil.getConnection();
            PreparedStatement ps = connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Book book = createBook(rs);
                books.add(book);
            }
        } catch (SQLException e) {
            handleException(e);
        } finally {
            DBUtil.closeConnection(connection);
        }
        return books;
    }

    /**
     * 根据id获取书籍
     *
     * @param id int
     * @return User
     */
    @Override
    public Book get(int id) {
        String sql = "SELECT * FROM Book WHERE id = ?";
        Connection connection = null;
        try {
            connection = DBUtil.getConnection();
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return createBook(rs);
            }
        } catch (SQLException e) {
            handleException(e);
        } finally {
            DBUtil.closeConnection(connection);
        }
        return null;
    }

    /**
     * 根据参数获取书籍
     *
     * @param param String
     * @return Book
     */
    public List<Book> get(String param) {
        List<Book> books = new ArrayList<>();
        String sql = "SELECT * FROM Book WHERE name like ? or isbn like ? or author like ?";
        Connection connection = null;
        try {
            connection = DBUtil.getConnection();
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, "%" + param + "%");
            ps.setString(2, "%" + param + "%");
            ps.setString(3, "%" + param + "%");
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Book book = createBook(rs);
                books.add(book);
            }
        } catch (SQLException e) {
            handleException(e);
        } finally {
            DBUtil.closeConnection(connection);
        }
        return books;
    }

    /**
     * 创建书籍
     *
     * @param rs ResultSet
     * @return Book
     * @throws SQLException
     */
    private Book createBook(ResultSet rs) throws SQLException {
        Book book;
        String category = rs.getString("category");
        if (BookCategory.COMPUTER.name().equalsIgnoreCase(category)) {
            book = new ComputerBook();
        } else if (BookCategory.MEDICINE.name().equalsIgnoreCase(category)) {
            book = new MedicalBook();
        } else if (BookCategory.LITERATURE.name().equalsIgnoreCase(category)) {
            book = new LiteratureBook();
        } else if (BookCategory.LAW.name().equalsIgnoreCase(category)) {
            book = new LawBook();
        } else if (BookCategory.OTHER.name().equalsIgnoreCase(category)) {
            book = new Book();
        } else {
            book = new Book();
        }
        book.setId(rs.getInt("id"));
        book.setName(rs.getString("name"));
        book.setAuthor(rs.getString("author"));
        book.setPublishDate(rs.getTimestamp("publish_date"));
        book.setIsbn(rs.getString("isbn"));
        book.setCategory(rs.getString("category"));
        book.setClassification(rs.getString("classification"));
        return book;
    }
}