package com.library.manage.service;

import com.library.manage.dao.BookDAO;
import com.library.manage.pojo.Book;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

/**
 * 书籍管理
 */
public class BookManager {
    /**
     * 书籍数据访问对象
     */
    private final BookDAO bookDAO = new BookDAO();

    /**
     * 查看书籍
     */
    public void viewBooks(Scanner scanner) {
        while (true) {
            try {
                List<Book> books = bookDAO.list();
                if (books.isEmpty()) {
                    System.out.println("**************** 目前没有任何书籍！ ****************");
                } else {
                    System.out.print("**************** 按照类别展示 (yes) 或 展示所有 (其它输入): ");
                    String choice = scanner.nextLine().trim();
                    if (!choice.equalsIgnoreCase("yes")) {
                        for (Book book : books) {
                            System.out.println(book.toString());
                        }
                    } else {
                        Map<String, List<Book>> categoryBooks = new HashMap<>();
                        for (Book book : books) {
                            String category = book.getCategory();
                            if (categoryBooks.containsKey(category)) {
                                categoryBooks.get(category).add(book);
                            } else {
                                categoryBooks.put(category, new java.util.ArrayList<>());
                                categoryBooks.get(category).add(book);
                            }
                        }
                        for (Map.Entry<String, List<Book>> entry : categoryBooks.entrySet()) {
                            System.out.println("**************** " + entry.getKey() + " ****************");
                            for (Book book : entry.getValue()) {
                                System.out.println(book.toString());
                            }
                        }

                    }
                }
            } catch (Exception e) {
                System.out.println("**************** 查看书籍失败! " + e.getMessage());
            }

            System.out.print("**************** 继续查看书籍 (yes) 或 返回首页 (其它输入): ");
            String choice = scanner.nextLine().trim();
            if (!choice.equalsIgnoreCase("yes")) {
                return;
            }
        }
    }

    /**
     * 搜索书籍
     *
     * @param scanner Scanner
     */
    public void searchBooks(Scanner scanner) {
        while (true) {
            try {
                System.out.print("**************** Enter keyword (作者、书名或者ISBN): ");
                String keyword = scanner.nextLine();
                List<Book> books = bookDAO.get(keyword);
                if (books.isEmpty()) {
                    System.out.println("**************** 没有搜索到书籍! ****************");
                } else {
                    for (Book book : books) {
                        System.out.println(book.toString());
                    }
                }
            } catch (Exception e) {
                System.out.println("**************** 搜索书籍失败! " + e.getMessage());
            }

            System.out.print("**************** 继续搜索书籍 (yes) 或 返回首页 (其它输入): ");
            String choice = scanner.nextLine().trim();
            if (!choice.equalsIgnoreCase("yes")) {
                return;
            }
        }
    }

    /**
     * 添加书籍
     *
     * @param scanner Scanner
     */
    public void addBook(Scanner scanner) {
        while (true) {
            try {
                System.out.print("**************** Enter 书名: ");
                String name = scanner.nextLine();
                System.out.print("**************** Enter 作者: ");
                String author = scanner.nextLine();
                System.out.print("**************** Enter ISBN: ");
                String isbn = scanner.nextLine();

                // 显示类别选项
                System.out.println("**************** 请选择类别: ");
                System.out.println("1. COMPUTER（计算机）");
                System.out.println("2. MEDICINE（医学）");
                System.out.println("3. LITERATURE（文学）");
                System.out.println("4. LAW（法律）");
                System.out.println("5. OTHER（其它）");
                System.out.print("**************** Enter 类别编号 (1-5): ");
                int categoryChoice = Integer.parseInt(scanner.nextLine());

                // 映射数字到类别字符串
                String category;
                switch (categoryChoice) {
                    case 1:
                        category = "COMPUTER";
                        break;
                    case 2:
                        category = "MEDICINE";
                        break;
                    case 3:
                        category = "LITERATURE";
                        break;
                    case 4:
                        category = "LAW";
                        break;
                    case 5:
                        category = "OTHER";
                        break;
                    default:
                        System.out.print("**************** 无效的类别编号! 请重新输入.");
                        continue;
                }

                System.out.print("**************** Enter 二级分类: ");
                String classification = scanner.nextLine();

                Book book = new Book();
                book.setName(name);
                book.setAuthor(author);
                book.setIsbn(isbn);
                book.setCategory(category);
                book.setClassification(classification);

                if (bookDAO.add(book) > 0) {
                    System.out.println("**************** 添加书籍成功! ****************");
                } else {
                    System.out.println("**************** 添加书籍失败! ****************");
                }
            } catch (Exception e) {
                System.out.println("**************** 添加书籍失败! " + e.getMessage());
            }

            System.out.print("**************** 继续添加书籍 (yes) 或 返回首页 (其它输入): ");
            String choice = scanner.nextLine().trim();
            if (!choice.equalsIgnoreCase("yes")) {
                return;
            }
        }
    }

    /**
     * 删除书籍
     *
     * @param scanner Scanner
     */
    public void deleteBook(Scanner scanner) {
        while (true) {
            try {
                System.out.print("**************** Enter ISBN of book to delete: ");
                String isbn = scanner.nextLine();
                if (bookDAO.delete(isbn) > 0) {
                    System.out.println("**************** 删除书籍成功！****************");
                } else {
                    System.out.println("**************** 删除书籍失败！****************");
                }
            } catch (Exception e) {
                System.out.println("**************** 删除书籍失败! " + e.getMessage());
            }

            System.out.print("**************** 继续删除书籍 (yes) 或 返回首页 (no): ");
            String choice = scanner.nextLine().trim();
            if (!choice.equalsIgnoreCase("yes")) {
                return;
            }
        }
    }

    /**
     * 备份书籍
     */
    public void backupBooks() {
        try {
            // 项目根目录和备份目录
            String projectRoot = Paths.get("").toAbsolutePath().toString();
            String backupDir = Paths.get(projectRoot, "backups").toString();
            Files.createDirectories(Paths.get(backupDir));

            // 删除backups下的备份文件（如果存在）
            File backupsDir = new File(backupDir);
            if (backupsDir.exists()) {
                File[] files = backupsDir.listFiles();
                for (File file : files) {
                    file.delete();
                }
            }

            // 临时文件名和目标文件名
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss");
            String timestamp = dateFormat.format(new Date());
            String fileName = "books_backup_" + timestamp + ".csv";
            String filePath = Paths.get(backupDir, fileName).toString();

            // 查询书籍数据
            List<Book> books = bookDAO.list();

            // 写入 CSV 格式到临时文件
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath));
                 CSVPrinter csvPrinter = new CSVPrinter(writer, CSVFormat.DEFAULT.withHeader("ID", "Name", "Author", "ISBN", "PublishedDate", "Category", "Classification"))) {
                for (Book book : books) {
                    csvPrinter.printRecord(
                            book.getId(),
                            book.getName(),
                            book.getAuthor(),
                            book.getIsbn(),
                            book.getPublishDate(),
                            book.getCategory(),
                            book.getClassification());
                }
            }
        } catch (Exception e) {
            System.out.println("**************** 备份书籍失败! " + e.getMessage());
        }
    }
}