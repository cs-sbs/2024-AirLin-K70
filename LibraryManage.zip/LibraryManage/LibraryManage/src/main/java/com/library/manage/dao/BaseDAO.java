package com.library.manage.dao;

import com.library.manage.util.DBUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public abstract interface BaseDAO<T> {

    /**
     * 获取总数
     */
    default public int getTotal(String tableName) {
        int total = 0;
        String sql = "SELECT COUNT(*) FROM " + tableName;
        Connection connection = null;
        try {
            connection = DBUtil.getConnection();
            PreparedStatement ps = connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                total = rs.getInt(1);
            }
        } catch (SQLException e) {
            handleException(e);
        } finally {
            DBUtil.closeConnection(connection);
        }
        return total;
    }

    /**
     * 添加
     *
     * @param t T
     * @return int
     */
    public abstract int add(T t);

    /**
     * 删除
     *
     * @param id int
     */
    public abstract int delete(int id);

    /**
     * 根据id获取
     *
     * @param id int
     * @return User
     */
    public abstract T get(int id);

    /**
     * 异常处理方法
     *
     * @param e SQLException
     */
    default void handleException(Exception e) {
        System.err.println("SQL Error: " + e.getMessage());
        e.printStackTrace();
    }
}