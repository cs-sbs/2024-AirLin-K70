package com.library.manage.util;

import com.library.manage.service.BookManager;

/**
 * 多线程支持：系统需要实现一个数据定期备份功能，备份操作应在后台独立线程中进行，不影响用户的正常操作。
 */
public class BackupTask implements Runnable {
    private BookManager bookManager;

    public BackupTask(BookManager bookManager) {
        this.bookManager = bookManager;
    }

    @Override
    public void run() {
        while (true) {
            try {
                Thread.sleep(60000); // 每 60 秒备份一次
                bookManager.backupBooks();
            } catch (InterruptedException e) {
                System.out.println("Backup interrupted." + e.getMessage());
            }
        }
    }
}