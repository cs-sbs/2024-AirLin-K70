package com.library.manage.service;

import com.library.manage.dao.UserDAO;
import com.library.manage.pojo.User;
import org.apache.commons.lang3.StringUtils;

import java.util.Scanner;

/**
 * 用户管理
 */
public class UserManager {
    /**
     * 当前登录用户
     */
    private User loggedInUser;

    /**
     * 用户数据访问对象
     */
    private final UserDAO userDAO = new UserDAO();

    /**
     * 注册用户
     */
    public void register(Scanner scanner) {
        while (true) {
            try {
                System.out.print("**************** Enter 用户名: ");
                String username = scanner.nextLine().trim();
                System.out.print("**************** Enter 密码: ");
                String password = scanner.nextLine().trim();
                System.out.print("**************** 是否是管理员? (yes/no): ");
                boolean isAdmin = scanner.nextLine().equalsIgnoreCase("yes");

                if (StringUtils.isEmpty(username) || StringUtils.isEmpty(password)) {
                    System.out.println("**************** 用户名和密码不能为空！请重新输入。****************");
                    System.out.print("**************** 继续输入 (yes) 或 返回首页 (其它输入): ");
                    String choice = scanner.nextLine().trim();
                    if (!choice.equalsIgnoreCase("yes")) {
                        return;
                    }
                    continue;
                }

                User user = new User();
                user.setUsername(username);
                user.setPassword(password);
                user.setAdmin(isAdmin ? "yes" : "no");

                if (userDAO.add(user) > 0) {
                    System.out.println("**************** 用户注册成功! **************** ");
                } else {
                    System.out.println(" **************** 用户注册失败! **************** ");
                }
            } catch (Exception e) {
                System.out.println("**************** 用户注册失败! " + e.getMessage());
            }

            System.out.print("**************** 继续注册 (yes) 或 返回首页 (其它输入): ");
            String choice = scanner.nextLine().trim();
            if (!choice.equalsIgnoreCase("yes")) {
                return;
            }
        }
    }

    /**
     * 登录
     *
     * @param scanner Scanner
     */
    public void login(Scanner scanner) {
        while (true) {
            try {
                System.out.print("Enter 用户名: ");
                String username = scanner.nextLine().trim();
                System.out.print("Enter 密码: ");
                String password = scanner.nextLine().trim();;

                if (StringUtils.isEmpty(username) || StringUtils.isEmpty(password)) {
                    System.out.println("**************** 用户名和密码不能为空！请重新输入。****************");
                    System.out.print("**************** 继续输入 (yes) 或 返回首页 (其它输入): ");
                    String choice = scanner.nextLine().trim();
                    if (!choice.equalsIgnoreCase("yes")) {
                        return;
                    }
                    continue;
                }

                // 数据库中寻找
                User user = userDAO.get(username, password);
                if (user != null) {
                    loggedInUser = user;
                    System.out.println("**************** 登录成功! ****************");
                    return;
                }

                System.out.println("**************** 用户名或密码不存在！**************** ");
            } catch (Exception e) {
                System.out.println("**************** 登录异常！" + e.getMessage());
            }

            System.out.print("**************** 继续登录 (yes) 或 返回首页 (其它输入): ");
            String choice = scanner.nextLine().trim();
            if (!choice.equalsIgnoreCase("yes")) {
                return;
            }
        }
    }

    /**
     * 登出
     */
    public void logout() {
        try {
            if (loggedInUser != null) {
                System.out.println("**************** 退出成功！****************");
                loggedInUser = null;
            } else {
                System.out.println("**************** 当前未登录！****************");
            }
        } catch (Exception e) {
            System.out.println("**************** 登出异常！" + e.getMessage());
        }
    }

    /**
     * 是否是管理员登录
     *
     * @return boolean
     */
    public boolean isAdminLoggedIn() {
        return loggedInUser != null && loggedInUser.isAdmin();
    }

    /**
     * 是否登录
     *
     * @return boolean
     */
    public boolean isLoggedIn() {
        return loggedInUser != null;
    }
}