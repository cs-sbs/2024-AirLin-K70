package com.library.manage.dao;


import com.library.manage.pojo.User;
import com.library.manage.util.DBUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class UserDAO implements BaseDAO<User> {

    /**
     * 获取用户总数
     */
    public int getTotal() {
        return getTotal("User");
    }

    /**
     * 添加用户
     *
     * @param bean User
     * @return int
     */
    @Override
    public int add(User bean) {
        String sql = "INSERT INTO User (username, password, admin) VALUES (?, ?, ?)";
        Connection connection = null;

        try {
            connection = DBUtil.getConnection();
            PreparedStatement ps = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, bean.getUsername());
            ps.setString(2, bean.getPassword());
            ps.setString(3, bean.getAdmin());

            int res = ps.executeUpdate();

            ResultSet generatedKeys = ps.getGeneratedKeys();
            if (generatedKeys.next()) {
                int id = generatedKeys.getInt(1);
                bean.setId(id);
            }
            return res;
        } catch (SQLException e) {
            handleException(e);
        } finally {
            DBUtil.closeConnection(connection);
        }
        return 0;
    }


    /**
     * 删除用户
     *
     * @param id int
     */
    @Override
    public int delete(int id) {
        String sql = "DELETE FROM User WHERE id = ?";
        Connection connection = null;
        try {
            connection = DBUtil.getConnection();
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setInt(1, id);
            return ps.executeUpdate();
        } catch (SQLException e) {
            handleException(e);
        } finally {
            DBUtil.closeConnection(connection);
        }
        return 0;
    }

    /**
     * 根据id获取用户
     *
     * @param id int
     * @return User
     */
    @Override
    public User get(int id) {
        User bean = null;
        String sql = "SELECT * FROM User WHERE id = ?";
        Connection connection = null;
        try {
            connection = DBUtil.getConnection();
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                bean = new User();
                bean.setId(rs.getInt("id"));
                bean.setUsername(rs.getString("username"));
                bean.setPassword(rs.getString("password"));
                bean.setAdmin(rs.getString("admin"));
            }
        } catch (SQLException e) {
            handleException(e);
        } finally {
            DBUtil.closeConnection(connection);
        }
        return bean;
    }

    /**
     * 根据用户名获取用户
     *
     * @param username String
     * @return User
     */
    public User get(String username) {
        User bean = null;
        String sql = "SELECT * FROM User WHERE username = ?";
        Connection connection = null;
        try {
            connection = DBUtil.getConnection();
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, username);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                bean = new User();
                bean.setId(rs.getInt("id"));
                bean.setUsername(rs.getString("username"));
                bean.setPassword(rs.getString("password"));
                bean.setAdmin(rs.getString("admin"));
            }
        } catch (SQLException e) {
            handleException(e);
        } finally {
            DBUtil.closeConnection(connection);
        }
        return bean;
    }

    /**
     * 根据用户名和密码获取用户
     *
     * @param username String
     * @param password String
     * @return User
     */
    public User get(String username, String password) {
        User bean = null;
        String sql = "SELECT * FROM User WHERE username = ? AND password = ?";
        Connection connection = null;
        try {
            connection = DBUtil.getConnection();
            PreparedStatement ps = connection.prepareStatement(sql);

            ps.setString(1, username);
            ps.setString(2, password);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                bean = new User();
                bean.setId(rs.getInt("id"));
                bean.setUsername(rs.getString("username"));
                bean.setPassword(rs.getString("password"));
                bean.setAdmin(rs.getString("admin"));
            }
        } catch (SQLException e) {
            handleException(e);
        } finally {
            DBUtil.closeConnection(connection);
        }
        return bean;
    }
}